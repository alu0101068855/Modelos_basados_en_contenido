import { Gestor } from './gestor_ficheros'
import { MatrizC } from './matrizc';
import { Matriz }  from './matrizz'
import { StopWords }  from './stopWords'

function help() {
  console.log("Modo de empleo: node ../dist/index.js fichero.txt");
  console.log("Pruebe 'node ../dist/index.js --help' para más información");
}

function mensaje_ayuda () {
  console.log("Practica : Sistemas de recomendacion. Modelos basados en contenidos");
  console.log("Utilidad que recibe un fichero con una serie de documentos y");
  console.log("genera valores de pesos (frecuencias) y similitudes de sus términos");
}

if (process.argv.length == 2 || process.argv.length != 5){
  help();
}

if (process.argv.length == 5){
  if (process.argv[2] == "-h" || process.argv[2] == "--help"){
    mensaje_ayuda();
  }
  else {
    const fileName: string = process.argv[2];
    const fileName2: string = process.argv[3];
    const fileName3: string = process.argv[4];
    let gestorejemplo = new Gestor(fileName);
    let gestorcambio = new Gestor(fileName3);
    let gestorStop = new Gestor(fileName2);
    let matrizejemplo = new Matriz(gestorejemplo);
    let stopWords = new StopWords(gestorStop);
    
    let contenidoCambio = gestorcambio.getContent();
    
    matrizejemplo.deleteStopWords(stopWords, contenidoCambio);
    matrizejemplo.sinRepetir();
    matrizejemplo.calculoTF();
    matrizejemplo.calculoIDF();
    matrizejemplo.calculoTFIDF();
    matrizejemplo.showMatrixSimilitud();
    matrizejemplo.similitudDocumentos();
    matrizejemplo.MatrixCoseno();
    matrizejemplo.showMatrixCoseno();  
    
    
   
  }
}