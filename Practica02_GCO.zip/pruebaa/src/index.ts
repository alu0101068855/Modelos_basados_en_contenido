import { Gestor } from './gestor_ficheros'
import { Matriz }  from './matrizz'
import { StopWords }  from './stopWords'

function help() {
  console.log("Modo de empleo: node ../dist/index.js fichero.txt");
  console.log("Pruebe 'node ../dist/index.js --help' para más información");
}

function mensaje_ayuda () {
  console.log("Practica : Sistemas de recomendacion. Modelos basados en contenidos");
  console.log("Utilidad que recibe un fichero con una serie de documentos y");
  console.log("genera valores de pesos (frecuencias) y similitudes de sus términos");
}

if (process.argv.length == 2 || process.argv.length != 3){
  help();
}

if (process.argv.length == 3){
  if (process.argv[2] == "-h" || process.argv[2] == "--help"){
    mensaje_ayuda();
  }
  else {
    const fileName: string = process.argv[2];
    let gestorejemplo = new Gestor(fileName);
    let gestorStop = new Gestor('stop-words-en.txt');
    let matrizejemplo = new Matriz(gestorejemplo);
    let stopWords = new StopWords(gestorStop);
    matrizejemplo.deleteStopWords(stopWords);
    matrizejemplo.sinRepetir();
    matrizejemplo.calculoTF();
    matrizejemplo.calculoIDF();
    matrizejemplo.calculoTFIDF();
    matrizejemplo.showMatrixSimilitud();
    matrizejemplo.similitudDocumentos();
    matrizejemplo.MatrixCoseno();
    matrizejemplo.showMatrixCoseno();  
  }
}