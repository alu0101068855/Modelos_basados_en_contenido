"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
let prue = "hola mundo";
console.log(prue);
