# Sistemas de recomendación

### Grupo:
- Marcos Jesús Santana Ramos (alu0101033471)
- Carlos Pío Reyes (alu0101132945)
- Héctor Abreu Acosta (alu0101068855)
