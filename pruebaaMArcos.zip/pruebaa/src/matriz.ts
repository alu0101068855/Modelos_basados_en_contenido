import { writeHeapSnapshot } from 'v8';
import { resourceLimits } from 'worker_threads';
import { Gestor } from './gestor_ficheros'
import { StopWords }  from './stopWords'


interface wordF {
  word: string,
  rep: number
}

export class Matriz0 {
  private stop_words: string[] = ["a","an","and","with","this","these","those","that","as","of","the","to","from","is","isn't","it","it's","but","in","be"]; 
  // Expresión regular para eliminar puntos, comas, etc
  private regex = /[.,;:?\s]/g;
  private words: string[];
  private fmatrix: wordF[];
  private fMatrixRep: wordF[];


  constructor(contenido: Gestor){
    this.words = contenido.getContent().split(' ');
    for (let i: number = 0; i != this.words.length; i++){
      // Eliminar puntos, comas, etc
      this.words[i] = this.words[i].replace(this.regex, '');
      // Poner palabras en minuscula
      this.words[i] = this.words[i].toLowerCase();
    }
    // Elimina "palabras" vacías
    let index = this.words.indexOf('', 0);
    if(index > -1){
      this.words.splice(index, 1);
    }
    console.log(this.words);
  };

  getAllWords(): string[]{
    return this.words;
  }
  deleteStopWords(stopW: StopWords){
    
  }

  getWords(): string[]{
    for (let i: number = 0; i != this.stop_words.length; i++){
      for (let j: number = 0; j != this.words.length; j++){
        let index = this.words.indexOf(this.stop_words[i], 0);
        if(index > -1){
          this.words.splice(index, 1);
        }  
      }    
    }
    return this.words;
  }

  getNumberOfWords(){
    return this.getWords().length;
  }

  fillMatrix(){
    let aux: string[] = this.getWords();
    this.fmatrix = []; 
    aux.forEach(element1 => {
      let cont:number = 0;
      aux.forEach(element2 => {
        if(element1 == element2){
          cont++;
        }
      });
      let auxWord: wordF = {
        word: element1,
        rep: cont
      }; 
      this.fmatrix.push(auxWord);
    });
  }  

  fillMatrixRep(){
    this.fMatrixRep = [];
    this.fmatrix.forEach(element => {
      if(element.rep > 1){
        this.fMatrixRep.push(element);
      }
    });
  }

  showMatrixRep(){
    console.log(this.fMatrixRep);
  }

  showMatrix(){
    console.log(this.fmatrix);
  }

}
