"use strict";
exports.__esModule = true;
exports.Matriz0 = void 0;
var Matriz0 = /** @class */ (function () {
    function Matriz0(contenido) {
        this.stop_words = ["a", "an", "and", "with", "this", "these", "those", "that", "as", "of", "the", "to", "from", "is", "isn't", "it", "it's", "but", "in", "be"];
        // Expresión regular para eliminar puntos, comas, etc
        this.regex = /[.,;:?\s]/g;
        this.words = contenido.getContent().split(' ');
        for (var i = 0; i != this.words.length; i++) {
            // Eliminar puntos, comas, etc
            this.words[i] = this.words[i].replace(this.regex, '');
            // Poner palabras en minuscula
            this.words[i] = this.words[i].toLowerCase();
        }
        // Elimina "palabras" vacías
        var index = this.words.indexOf('', 0);
        if (index > -1) {
            this.words.splice(index, 1);
        }
        console.log(this.words);
    }
    ;
    Matriz0.prototype.getAllWords = function () {
        return this.words;
    };
    Matriz0.prototype.deleteStopWords = function (stopW) {
    };
    Matriz0.prototype.getWords = function () {
        for (var i = 0; i != this.stop_words.length; i++) {
            for (var j = 0; j != this.words.length; j++) {
                var index = this.words.indexOf(this.stop_words[i], 0);
                if (index > -1) {
                    this.words.splice(index, 1);
                }
            }
        }
        return this.words;
    };
    Matriz0.prototype.getNumberOfWords = function () {
        return this.getWords().length;
    };
    Matriz0.prototype.fillMatrix = function () {
        var _this = this;
        var aux = this.getWords();
        this.fmatrix = [];
        aux.forEach(function (element1) {
            var cont = 0;
            aux.forEach(function (element2) {
                if (element1 == element2) {
                    cont++;
                }
            });
            var auxWord = {
                word: element1,
                rep: cont
            };
            _this.fmatrix.push(auxWord);
        });
    };
    Matriz0.prototype.fillMatrixRep = function () {
        var _this = this;
        this.fMatrixRep = [];
        this.fmatrix.forEach(function (element) {
            if (element.rep > 1) {
                _this.fMatrixRep.push(element);
            }
        });
    };
    Matriz0.prototype.showMatrixRep = function () {
        console.log(this.fMatrixRep);
    };
    Matriz0.prototype.showMatrix = function () {
        console.log(this.fmatrix);
    };
    return Matriz0;
}());
exports.Matriz0 = Matriz0;
