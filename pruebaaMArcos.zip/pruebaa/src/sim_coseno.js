"use strict";
exports.__esModule = true;
exports.sim_coseno = void 0;
var sim_coseno = /** @class */ (function () {
    function sim_coseno() {
    }
    return sim_coseno;
}());
exports.sim_coseno = sim_coseno;
