export class sim_coseno{
  
}